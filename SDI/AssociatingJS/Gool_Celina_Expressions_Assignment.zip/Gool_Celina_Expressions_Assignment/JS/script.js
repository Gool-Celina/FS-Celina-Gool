/*
Celina Gool
SDI Section 3
Expression Assignment
1/15/2015
 */

//Prompt and Alert

//Calculate the age of a dog in human and dog years

var numberSlice = prompt("How many slices is the pizza?");
var numberPeople =prompt("How many people on the guest list?");
var numberPizza = prompt("How many pizza ordered?");


var total = prompt(numberSlice /numberPeople);


//multiply number of boxes of pizza by the slices per box & then divide it by the number of people

//print out the output of how much each person will eat

alert(numberSlice /numberPeople);